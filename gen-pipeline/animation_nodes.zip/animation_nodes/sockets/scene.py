import bpy
from bpy.props import *
from bpy.types import Scene
from .. events import propertyChanged
from .. base_types import AnimationNodeSocket, PythonListSocket

class SceneSocket(bpy.types.NodeSocket, AnimationNodeSocket):
    bl_idname = "an_SceneSocket"
    bl_label = "Scene Socket"
    dataType = "Scene"
    drawColor = (0.2, 0.3, 0.4, 1)
    storable = False
    comparable = True

    scene: PointerProperty(type = Scene, update = propertyChanged)
    useGlobalScene: BoolProperty(name = "Use Global Scene", default = True,
        description = "Use the global scene for this node tree", update = propertyChanged)

    def drawProperty(self, layout, text, node):
        row = layout.row(align = True)
        if self.useGlobalScene:
            if text != "": text += ": "
            row.label(text = text + repr(self.nodeTree.scene.name))
        else:
            row.prop(self, "scene", text = text)
        row.prop(self, "useGlobalScene", text = "", icon = "WORLD")

    def getValue(self):
        if self.useGlobalScene:
            return self.nodeTree.scene
        return self.scene

    def setProperty(self, data):
        self.scene, self.useGlobalScene = data

    def getProperty(self):
        return self.scene, self.useGlobalScene

    @classmethod
    def getDefaultValue(cls):
        return None

    @classmethod
    def correctValue(cls, value):
        if isinstance(value, Scene) or value is None:
            return value, 0
        return cls.getDefaultValue(), 2


class SceneListSocket(bpy.types.NodeSocket, PythonListSocket):
    bl_idname = "an_SceneListSocket"
    bl_label = "Scene List Socket"
    dataType = "Scene List"
    baseType = SceneSocket
    drawColor = (0.2, 0.3, 0.4, 0.5)
    storable = False
    comparable = False

    useGlobalScene: BoolProperty(name = "Use Global Scene", default = True,
        description = "Use the global scene for this node tree", update = propertyChanged)

    def drawProperty(self, layout, text, node):
        row = layout.row(align = True)
        if self.useGlobalScene:
            if text != "": text += ": "
            row.label(text = text + "[{}]".format(repr(self.nodeTree.scene.name)))
        else:
            if not text: text = self.text
            row.label(text = text)
        row.prop(self, "useGlobalScene", icon = "WORLD", text = "")

    def getValue(self):
        return [self.nodeTree.scene]

    @classmethod
    def getCopyExpression(cls):
        return "value[:]"

    @classmethod
    def correctValue(cls, value):
        if isinstance(value, list):
            if all(isinstance(element, Scene) or element is None for element in value):
                return value, 0
        return cls.getDefaultValue(), 2
